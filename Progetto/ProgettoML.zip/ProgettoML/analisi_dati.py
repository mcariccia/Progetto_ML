import pandas as pd
import numpy as np
from scipy.stats import mode
import matplotlib.pyplot as plt



def fetch_dataset():
    # inizializzo il dataset e aggiungo i nomi delle features
    columns = ['fLength', 'fWidth', 'fSize', 'fConc', 'fConc1', 'fAsym', 'fM3Long', 'fM3Trans', 'fAlpha', 'fDist', 'class']
    return pd.read_csv("dataset/magic04.data", names=columns)


    # Questa funzione riceve in ingresso il dataset restituito dalla funzione fetch_dataset()
    # ed è una variabile di tipo dataframe che rappresenta ciò che restiuisce pandas
def extractXy(dataset):
    # Estraggo tutte le colonne del dataset in quanto sono gli attributi e classe del dataset
    # Estraggo le colonne degli attributi
    X = dataset[dataset.columns[:-1]]
    # Estraggo la colonna del vettore delle classi
    y = dataset[dataset.columns[-1]]

    return X, y # restituisco due oggetti di tipo dataframe che rappresentano il dataset
    # diviso del feature e per classe

    
# Definisco una funzione attributi che riceve in ingresso la variabile X che rappresenta 
# tutte le colonne degli attributi. 

def attributi(X):
    # Estrazione di tutte gli attributi in vettori per elaborazione dei dati
    # Prima li estraggo attributo per attributo come lista e poi li converto
    # in array di numpy

    featuresList = X.columns # ottengo una lista di liste degli attributi

    featuresArrays = []      # inizializzo una lista vuota

    for feature in featuresList:  # con questo ciclo for converto ogni lista in array
        featureArray = np.array(X[feature].tolist())
        featuresArrays.append(featureArray)

    attributi = np.vstack(featuresArrays) # ottengo un array di array sarebbe una matrice
    # le cui colonne sono gli attributi. la funzione vstack(): 
    # prende una riga (il record) e lo mette uno sopra l'altro. Cioè mette una riga una sopra l'altra

    return attributi


# la funzione che esegue l'analisi dei dati 
# riceve in ingresso. Riceve una variabile di tipo Dataframe, io gli passo la X
# che viene restituita dalla funzione extractXy(dataset)
def dataAnalysis(features):
    # "calcolo" della media
    medie_attributi = np.zeros(len(features.columns)) # inizializzo un array di zero per memorizzare le medie 
    # per ogni attributo
    # utlizzo la funzione describe() è una funzione che calcola diversi parametri media, deviazione standard, varianza
    for i, (feature, value) in enumerate(features.describe().loc['mean'].items()):
        medie_attributi[i] = value

    # calcolo della moda, mediana, percentili
    mode_attributi = []
    mediane_attributi = np.zeros(len(features.columns))
    percentili = []
    for i, array in enumerate(attributi(features)):
        # calcolo della moda
        moda = mode(array)
        # la funzione mode restituisce una variabile
        # di tipo stats._stats_py.ModeResult che ha come elemento 0 la moda e come elemento 1 il numero
        # di volte che si ripete
        mode_attributi = mode_attributi + [[moda[0], moda[1]]]

        # calcolo della mediana
        mediana = np.median(array)
        mediane_attributi[i] = mediana

        # calcolo dei percentili
        # calcolo dei percentili
        decimo_percentile = np.percentile(array, 10)
        venticinquesimo_percentile = np.percentile(array, 25)
        cinquantesimo_percentile = np.percentile(array, 50)
        settantacinquesimo_percentile = np.percentile(array, 75)
        novantesimo_percentile = np.percentile(array, 90)
        percentili = percentili + [[decimo_percentile, venticinquesimo_percentile, cinquantesimo_percentile, settantacinquesimo_percentile, novantesimo_percentile]]

    # "calcolo" della deviazione standard
    deviazione_standard_attributi = np.zeros(len(features.columns))
    for i, (feature, value) in enumerate(features.describe().loc['std'].items()):
        deviazione_standard_attributi[i] = value

    # "calcolo" della varianza
    varianza_attributi = np.zeros(len(features.columns))
    for i, (feature, value) in enumerate(features.describe().loc['std'].items()):
        varianza_attributi[i] = value**2

    # "calcolo" del range
    range_attributi = np.zeros(len(features.columns))
    range_values = features.describe().loc[['min', 'max']].diff().loc['max']
    for i, (feature, range_value) in enumerate(range_values.items()):
        range_attributi[i] = range_value

    # converto in array la lista di liste mode_attributi e pencentili
    mode_attributi = np.array(mode_attributi)
    percentili = np.array(percentili)

    # faccio la trasposta per avere ogni colonna l'attributo e nella riga il valore
    # corrispondente di media, mediana, moda etc
    medie_attributi = medie_attributi.T
    mode_attributi = mode_attributi.T
    mediane_attributi = mediane_attributi.T
    deviazione_standard_attributi = deviazione_standard_attributi.T
    varianza_attributi = varianza_attributi.T
    range_attributi = range_attributi.T
    percentili = percentili.T

    # calcolo della matrice di correlazione
    CorrelazionePear = features.corr()
    CorrelazioneSpe = features.corr(method='spearman')

    # creo singole variabili percentili
    perc_10 = percentili[0]
    perc_25 = percentili[1]
    perc_50 = percentili[2]
    perc_75 = percentili[3]
    perc_90 = percentili[4]

    return medie_attributi, mode_attributi, mediane_attributi, deviazione_standard_attributi, varianza_attributi, range_attributi, perc_10, perc_25, perc_50, perc_75, perc_90, CorrelazionePear, CorrelazioneSpe


# questa è funzione per creare le box plot
def create_boxplot(dataset):
    # Creo un boxplot per ogni feature, e li metto in una griglia 2x5

    # prendo tutte le colonne tranne l'ultima (la classe)
    # to_list() converte me lo converte in una lista, quindi posso dopo usare index()
    features = dataset.columns[:-1].to_list() # features prende tutti gli attributi 
    # e lo converte in lista
    # Il resto è abbastanza autoesplicativo e simile a @create_hist e @check_duplicates
    # creaiamo una figura
    fig, axes = plt.subplots(nrows=2, ncols=5, figsize=(25, 25))
    fig.suptitle('Boxplot delle features', fontsize=16)
    
    for x in features:
    
        plt.sca(axes[features.index(x) // 5][features.index(x) % 5]) # seleziona il subplot corretto
        plt.boxplot(dataset[x], patch_artist=True)
        # calcolo i percentili
        q50 = np.percentile(dataset[x], 50)
        q25 = np.percentile(dataset[x], 25)
        q75 = np.percentile(dataset[x], 75)
        q90= np.percentile(dataset[x], 90)
        percentiles = [25, 50, 75, 90]
        percentile_values = [q25, q50, q75, q90]
        
        # Calcola gli estremi dei baffi
        # Calcola l'IQR (Interquartile Range)
        iqr = q75 - q25

        # Calcola gli estremi dei baffi escludendo gli outlier
        whisker_min = np.max([min(dataset[x]), q25 - 1.5 * iqr])
        whisker_max = np.min([max(dataset[x]), q75 + 1.5 * iqr])
        # rappresento i baffi e i percentili
        plt.scatter([1]*len(percentile_values), percentile_values, marker='o', color='red', label='Percentili')
        plt.scatter([1, 1], [whisker_min, whisker_max], marker='x', color='blue', label='Estremi dei baffi')
        
        # Aggiungi le etichette per i percentili e gli estremi dei baffi
        
        for i, val in enumerate(percentile_values):
            plt.text(1.1, val, f'{percentiles[i]}%: {val:.2f}', va="top")
            
        plt.text(1.1, whisker_min, f'Min: {whisker_min:.2f}', va='center')
        plt.text(1.1, whisker_max, f'Max: {whisker_max:.2f}', va='center')

        # Aggiungi una legenda
        # Aggiungi la legenda in alto a sinistra con dimensioni personalizzate
        plt.legend(loc='upper left', bbox_to_anchor=(0, 1), prop={'size': 10})

        plt.xlabel(x)
    # il risultato di questo for un sub plot di iamo 10 attributi
    plt.show()


# creiamo l'istogramma
def create_hist(dataset):
    dataset['class'] = (dataset['class'] == 'g').astype(int)

    # creo un istogramma per ogni feature
    # in questo modo sono in grado di capire quale features potrebbero essere migliori da usare per la classificazione
    # e quali invece non sono molto significative

    features = dataset.columns[:-1]
    fig, axes = plt.subplots(nrows=2, ncols=5, figsize=(25, 15))
    fig.suptitle('Istogrammi delle features', fontsize=16)

    axes = axes.flatten() # trasformo la matrice 3x4 in un array di 12 elementi

    for i, x in enumerate(features):
        plt.sca(axes[i])

        # prendo qualsiasi record con classe 0 (quindi gamma) e
        # inserisce il suo singolo valore della singola feature nell'istogramma
        plt.hist(dataset[dataset["class"] == 0][x], color='red', bins=50, alpha=0.5, density=False, label='hadron')
        # posizioniamo nello stesso istogramma anche i valori della classe 1 (quindi hadron)
        # in questo modo riusciremo a capire dove sono presenti differenze tra le due classi
        plt.hist(dataset[dataset["class"] == 1][x], color='blue', bins=50, alpha=0.5, density=False, label='gamma')

        # bins = 50 è il numero di intervalli in cui dividere l'istogramma
        # alpha = 0.5 è la trasparenza dell'istogramma
        # density = True normalizza l'istogramma in modo che l'area totale del singolo bin sia uguale a 1
        # label = 'gamma' e label = 'hadron' sono le etichette che compariranno nella legenda
        plt.title(x, fontsize=15) # titolo dell'istogramma la singola feature
        plt.xlabel("Valore attributo "+ str(x), fontsize=15)
        plt.ylabel("Frequenza")
        plt.legend(loc='upper right')

    plt.show()


# questa funzione restituisce il plot dell'istogramma a barre e ci dice quanti valori unici per attiributo
def check_duplicates(dataset):
    features = dataset.columns[:-1]
    plt.figure(figsize=(12, 6))

    for x in features:
        datasetCounter = dataset.loc[~dataset.duplicated(subset=[x])].count()

        plt.bar(x, datasetCounter[x], label=x)
        plt.title('Valori unici per feature')
        plt.legend(loc='upper right', bbox_to_anchor=(1.12, 1), borderaxespad=0)

    plt.show()


# questa funzione crea un grafico a torta per visualizzare il partizionamento delle classi
def create_pie_class_distribution(y):
    y = y.tolist()
    p=(y.count(1)/len(y),y.count(0)/len(y)) #conto le occorrenze delle classi e le divido per il totale dei record
    #creo le stringhe con la classe e la percentuale rappresentata per la label
    a="Classe g: "+str(round(p[0],6)*100)+"%"
    b="Classe h: "+str(round(p[1],6)*100)+"%"
    #creo il diagramma a torta
    plt.pie(p, labels=[a,b])
    plt.show()


def print_analisi(data):
    # creo le colonne e le righe per il dataframe
    columns = ['fLength', 'fWidth', 'fSize', 'fConc', 'fConc1', 'fAsym', 'fM3Long', 'fM3Trans', 'fAlpha', 'fDist'] # nomi delle colonne
    index = ['media', 'moda', 'mediana', 'dev_std', 'varianza', 'range', '10%', '25%', '50%', '75%', '90%'] # nomi delle righe

    # creo un dataframe panda con i dati che ci siamo calcolati tramite la funzione dataAnalysis()
    # le colonne corrispondono agli attributi e quindi a columns
    # le righe corrispondo ai dati calcolati, quindi media, moda, mediana etc e quindi a index
    df = pd.DataFrame(data[:-2], columns=columns, index=index)

    # stampa analisi dati sulla console
    print('\nAnalisi dati:')
    print(df)

    # stampo la correlazione di pearson, anche questa l'abbiamo calcolata con la funzione dataAnalysis()
    print('\nCorrelazione di Pearson:')
    print(data[-2])
    #stampo la correlazione di spearman, anche questa l'abbiamo calcolata con la funzione dataAnalysis()
    print('\nCorrelazione di Spearman:')
    print(data[-1])


def analysis(dataset):
    X, y = extractXy(dataset) # lo divido in features e classi
    # STAMPO I RISULTATI
    # media, moda, mediana, deviazione standard, varianza, range, percentili,
    # correlazione di pearson, correlazione di spearman per ogni attributi
    print_analisi(dataAnalysis(X))
    # box plot features
    create_boxplot(dataset)
    # istogramma features
    create_hist(dataset)
    # istogramma a barre per duplicati (mostra i valori unici per ogni faeture)
    check_duplicates(dataset)
    # diagramma a torta per la distribuzione delle classi
    y = y.replace({'g': 1, 'h': 0})
    create_pie_class_distribution(y)