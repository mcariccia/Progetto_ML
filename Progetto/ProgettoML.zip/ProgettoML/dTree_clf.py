from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from metrics import compute_metrics, metrics_df
import matplotlib.pyplot as plt
import numpy as np
import datetime


# funzione che mette a paragone due metriche su un piano, accetta:
# lista o array con i valori della metrica e stringa con nome della metrica, prima asse x e poi y
def twod_plot(x, x_name, y, y_name, tipo):
    # plotto due metriche a paragone su un grafico a due dimensioni
    plt.plot(x,y)
    plt.xlabel(x_name, fontsize = 20)
    plt.ylabel(y_name, fontsize = 20)
    plt.title('Prestazioni su dataset %s' % tipo, fontsize = 20)
    plt.show()


def dTree(X, y, tipo, stratify=None):
    # suddivido il dataset in train e test set, con test_size=0.25, quindi il test set sarà composto dal 25% del dataset
    train_x, test_x, train_y, test_y = train_test_split(X, y, test_size=0.25, random_state=0, stratify=stratify)

    '''
    # come primo parametro valuto la max depth, max_v è il massimo valore per cui testare l'iperparametro, in questo caso 31
    metrics_test, max_depth = dtree_tuning_max_depth(train_x, test_x, train_y, test_y, 31)
    # trasformo le liste in dataframe
    df_metrics_test = metrics_df(range(1, max_depth), metrics_test)
    # stampo le metriche di valutazione per il test set
    print('Metriche di valutazione per il test set relativo al numero di profondità masssimo, dataset %s:\n' % tipo,  df_metrics_test)
    # variabile precisione
    prec = df_metrics_test.loc['Precision'].values
    # metto a paragone la max depth con la precision
    twod_plot(range(1, max_depth), "Max depth", prec, "Precision", tipo)
    #controllo il miglior valore di maxdepth per quanto riguarda la precisione e stampo anche il corrispondente
    #numero di TP classificati
    #estraggo l'argomento del massimo dalla lista di precision
    #visto che la max depth inizia da 1, aggiungo 1 all'argomento
    TP = df_metrics_test.loc['TP'].values
    i = np.argmax(prec)
    depthtuned = i + 1
    print("La profondità di albero, sul dataset %s, che porta precisione migliore è" % tipo, depthtuned, "che classifica", int(TP[i]),
          "TP con precisione", np.max(prec[i]))

    # come secondo parametro valuto il numero di foglie massimo, max_v è il massimo valore per cui testare l'iperparametro, in questo caso 31
    metrics_test, max_leaf_nodes = dtree_tuning_max_leaf_nodes(train_x, test_x, train_y, test_y, 31)
    # trasformo le liste in dataframe
    df_metrics_test = metrics_df(range(2, max_leaf_nodes), metrics_test)
    # stampo le metriche di valutazione per il test set
    print('Metriche di valutazione per il test set relativo al numero di foglie massimo, dataset %s:\n' % tipo, df_metrics_test)
    # variabile precisione
    prec = df_metrics_test.loc['Precision'].values
    # metto a paragone il numero di foglie con la precision
    twod_plot(range(2, max_leaf_nodes), "Max leaf nodes", prec, "Precision", tipo)
    # controllo il miglior valore di maxdepth per quanto riguarda la precisione e stampo anche il corrispondente
    # controllo il miglior valore di max leaf nodes per quanto riguarda la precisione e stampo anche il corrispondente
    # numero di TP classificati
    # estraggo l'argomento del massimo dalla lista di precision
    # visto che il max leaf nodes inizia da 2, aggiungo 2 all'argomento
    TP = df_metrics_test.loc['TP'].values
    i = np.argmax(prec)
    leaftuned = i + 2
    print("Il numero di foglie, sul dataset %s, che porta precisione migliore è" % tipo, leaftuned, "che classifica", int(TP[i]),
          "TP con precisione", np.max(prec[i]))
    '''

    # funzione per indurre ed utilizzare un albero decisionale composto dagli iperparametri decisi
    metrics_test, dTree_clf = dtree_tuned(train_x, train_y, test_x, test_y, 12, 16)
    # trasformo le liste in dataframe
    metrics_test = np.array(metrics_test).reshape(1, 10)
    df_metrics_test = metrics_df(["Tuned"], metrics_test)
    print('Metriche di valutazione per il test set, con albero tuned, su dataset %s:\n' % tipo, df_metrics_test)
    # chiamo la funzione per salvare uno schema dell'albero decisionale ottenuto
    # è possibile controllare tutte le immagini mostrnati l'albero nella cartella images/dTree
    tuned = "dataset_" + tipo + "_tuned"
    show_tree(dTree_clf, tuned)

    # come ultimo iperparametro valuto il minimo guadagno
    # creo una lista di minimi guadagni da testare
    l_min_gain = [0.1, 0.05, 0.03, 0.008, 0.0075, 0.005]
    # calcolo le metriche per ogni minimo guadagno
    metrics_test, l_min_gain = dtree_min_gain(train_x, test_x, train_y, test_y, l_min_gain, tipo)
    # trasformo le liste in dataframe
    df_metrics_test = metrics_df(l_min_gain, metrics_test)
    # stampo le metriche di valutazione per il test set
    print('Metriche di valutazione per il test set relativo al minimo guadagno, su dataset %s:\n' % tipo, df_metrics_test)

    # stampa "warning"
    print("\nPer poter visualizzare gli alberi decisionali, controllare la cartella images/dTree")
    print("Nome formattato nel seguente modo: tree + tipo dataset + tipo di albero (tuned, o con mingain specifico) + timestamp (data e ora)")

def show_tree(dTree_clf, tipo):
    fn = ['fLength', 'fWidth', 'fSize', 'fConc', 'fConc1', 'fAsym', 'fM3Long', 'fM3Trans', 'fAlpha', 'fDist']
    cn = ['h', 'g']

    # data e orario attuale
    timestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")

    # creo il nome del file
    filename = 'images/dTree/tree_' + tipo + '_' + timestamp + '.png'

    # faccio in modo che anche alberi di grandi dimensioni siano visibili con buona risoluzione
    fig, axes = plt.subplots(nrows=1, ncols=1, figsize=(4, 4), dpi=300)
    plot_tree(dTree_clf,
                feature_names=fn,
                class_names=cn,
                filled=True)
    fig.savefig(filename)


#come primo iperparametro valuto la max depth, max_v è il massimo valore per cui testare l'iperparametro
def dtree_tuning_max_depth(train_x, test_x, train_y, test_y, max_v):
    # creo una lista con le metriche di valutazione per ogni mav depth
    # perciò metrics[0] conterrà le metriche per depth=1, metrics[1] per depth=2, e così via
    metrics_test = []

    # calcolo le metriche per ogni max depth da 1 a max_v
    for md in range(1, max_v):
        # creo il classificatore
        dTree_clf = DecisionTreeClassifier(max_depth=md, random_state=0)
        # addestro il classificatore con la data matrix del training set e il corrispondente vettore di label
        dTree_clf.fit(train_x, train_y)
        # predico le classi utilizzando il classificatore
        pred_y_test = dTree_clf.predict(test_x)

        # calcolo la matrice di confusione per il test set e per il train set
        cm_test = confusion_matrix(test_y, pred_y_test, labels=[0, 1])

        # calcolo le metriche di valutazione per il test set e per il train set, e le inserisco nelle apposite liste
        metrics_test.append(compute_metrics(test_y, pred_y_test, cm_test))

    return metrics_test, max_v


#come secondo iperparametro valuto il numero di foglie, max_v è il massimo valore per cui testare l'iperparametro
def dtree_tuning_max_leaf_nodes(train_x, test_x, train_y, test_y, max_v):
    # creo una lista con le metriche di valutazione per ogni mav depth
    # perciò metrics[0] conterrà le metriche per depth=1, metrics[1] per depth=2, e così via
    metrics_test = []

    #calcolo le metriche per ogni numero di foglie da 2 a max_v, se il max depth doveva essere almeno 1, il max leaf deve essere almeno 2
    for ml in range(2, max_v):
        # creo il classificatore
        dTree_clf = DecisionTreeClassifier(max_leaf_nodes=ml, random_state=0)
        # addestro il classificatore con la data matrix del training set e il corrispondente vettore di label
        dTree_clf.fit(train_x, train_y)
        # predico le classi utilizzando il classificatore
        pred_y_test = dTree_clf.predict(test_x)

        # calcolo la matrice di confusione per il test set e per il train set
        cm_test = confusion_matrix(test_y, pred_y_test, labels=[0, 1])

        # calcolo le metriche di valutazione per il test set e per il train set, e le inserisco nelle apposite liste
        metrics_test.append(compute_metrics(test_y, pred_y_test, cm_test))

    return metrics_test, max_v


#creo una funzione per indurre ed utilizzare un albero decisionale composto dagli iperparametri decisi
def dtree_tuned(train_x, train_y, test_x, test_y, depthtuned, leaftuned):
    # creo il classificatore
    dTree_clf = DecisionTreeClassifier(max_depth=depthtuned, max_leaf_nodes=leaftuned, random_state=0)
    # addestro il classificatore con la data matrix del training set e il corrispondente vettore di label
    dTree_clf.fit(train_x, train_y)
    # predico le classi utilizzando il classificatore
    pred_y_test = dTree_clf.predict(test_x)
    # calcolo la matrice di confusione per il test set e per il train set
    cm_test = confusion_matrix(test_y, pred_y_test, labels=[0, 1])
    # calcolo le metriche di valutazione per il test set e per il train set, e le inserisco nelle apposite liste
    metrics = compute_metrics(test_y, pred_y_test, cm_test)

    return metrics, dTree_clf


#definisco una funzione per valutare l'ultimo iperparametro: il minimo guadagno
#passo una lista di minimi guadagni da testare
def dtree_min_gain(train_x, test_x, train_y, test_y, l_min_gain, tipo):
    # creo una lista con le metriche di valutazione per ogni minimo guadagno
    metrics_test = []

    for mid in l_min_gain:
        # creo il classificatore
        dTree_clf = DecisionTreeClassifier(min_impurity_decrease=mid, random_state=0)
        # addestro il classificatore con la data matrix del training set e il corrispondente vettore di label
        dTree_clf.fit(train_x, train_y)
        # predico le classi utilizzando il classificatore
        pred_y_test = dTree_clf.predict(test_x)
        # calcolo la matrice di confusione per il test set e per il train set
        cm_test = confusion_matrix(test_y, pred_y_test, labels=[0, 1])
        # calcolo le metriche di valutazione per il test set e per il train set, e le inserisco nelle apposite liste
        metrics_test.append(compute_metrics(test_y, pred_y_test, cm_test))

        label = tipo
        label = label + "_mingain_" + str(mid)

        show_tree(dTree_clf, label)

    return metrics_test, l_min_gain