from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix, roc_curve, auc
from metrics import compute_metrics, metrics_df, compute_performances
import matplotlib.pyplot as plt
import numpy as np


def kNN_classifier(train_x, test_x, train_y, test_y, k_values=range(1, 21)):
    # creo una lista con le metriche di valutazione per ogni k
    # perciò metrics[0] conterrà le metriche per k=1, metrics[1] per k=5, metrics[2] per k=10, metrics[3] per k=15, metrics[4] per k=20
    metrics_test = []
    metrics_train = []

    # for loop per provare diversi valori di k
    for k in k_values:
        #kNN classifier
        kNN_clf = KNeighborsClassifier(n_neighbors=k) # creo il classificatore kNN con iperparametro k={1, 5, 10, 15, 20}
        kNN_clf.fit(train_x, train_y) # addestro il modello kNN

        pred_y_test = kNN_clf.predict(test_x) # predico le classi del test set
        pred_y_train = kNN_clf.predict(train_x) # predico le classi del train set

        # calcolo la matrice di confusione per il test set e per il train set
        cm_test = confusion_matrix(test_y, pred_y_test, labels=[0, 1])
        cm_train = confusion_matrix(train_y, pred_y_train, labels=[0, 1])

        # calcolo le metriche di valutazione per il test set e per il train set
        metrics_test.append(compute_metrics(test_y, pred_y_test, cm_test))
        metrics_train.append(compute_metrics(train_y, pred_y_train, cm_train))

    return metrics_test, metrics_train, k_values


# questa funzione esegue il tuning del parametro k ma tenendo conto del parametro weight
def kNN_weights(train_x, test_x, train_y, test_y, k_values=range(1, 21)):
    # creo una lista con le metriche di valutazione per ogni k
    metrics_test = []
    metrics_train = []

    # for loop per provare diversi valori di k
    for k in k_values:
        #kNN classifier
        kNN_clf = KNeighborsClassifier(n_neighbors=k, weights="distance") # creo il classificatore kNN
        kNN_clf.fit(train_x, train_y) # addestro il modello kNN

        pred_y_test = kNN_clf.predict(test_x) # predico le classi del test set
        pred_y_train = kNN_clf.predict(train_x) # predico le classi del train set

        # calcolo la matrice di confusione per il test set e per il train set
        cm_test = confusion_matrix(test_y, pred_y_test, labels=[0, 1])
        cm_train = confusion_matrix(train_y, pred_y_train, labels=[0, 1])

        # calcolo le metriche di valutazione per il test set e per il train set
        metrics_test.append(compute_metrics(test_y, pred_y_test, cm_test))
        metrics_train.append(compute_metrics(train_y, pred_y_train, cm_train))

    return metrics_test, metrics_train, k_values


# questa funzione esegue il tuning del parametro k utilizzando la distanza Manhattan invece di quella euclidea
def kNN_manhattan(train_x, test_x, train_y, test_y, k_values=range(1, 21)):
    # creo una lista con le metriche di valutazione per ogni k
    metrics_test = []
    metrics_train = []

    # for loop per provare diversi valori di k
    for k in k_values:
        #kNN classifier
        kNN_clf = KNeighborsClassifier(n_neighbors=k, p=1) # creo il classificatore kNN
        kNN_clf.fit(train_x, train_y) # addesatro il modello kNN

        pred_y_test = kNN_clf.predict(test_x) # predico le classi del test set
        pred_y_train = kNN_clf.predict(train_x) # predico le classi del train set

        # calcolo la matrice di confusione per il test set e per il train set
        cm_test = confusion_matrix(test_y, pred_y_test, labels=[0, 1])
        cm_train = confusion_matrix(train_y, pred_y_train, labels=[0, 1])

        # calcolo le metriche di valutazione per il test set e per il train set
        metrics_test.append(compute_metrics(test_y, pred_y_test, cm_test))
        metrics_train.append(compute_metrics(train_y, pred_y_train, cm_train))

    return metrics_test, metrics_train, k_values


# questa funzione riceve in input il miglior valore di k trovato e se utilizzare il peso o che distanza
def kNN_tuned(train_x, test_x, train_y, test_y, kvalue, weight, distance):
    #kNN classifier
    kNN_clf = KNeighborsClassifier(n_neighbors=kvalue, weights=weight, p=distance) # creo il classificatore kNN
    kNN_clf.fit(train_x, train_y) # addestro il modello kNN

    pred_y_test = kNN_clf.predict(test_x) # predico le classi del test set
    pred_y_train = kNN_clf.predict(train_x) # predico le classi del train set

    # calcolo la matrice di confusione per il test set e per il train set
    cm_test = confusion_matrix(test_y, pred_y_test, labels=[0, 1])
    cm_train = confusion_matrix(train_y, pred_y_train, labels=[0, 1])

    # calcolo le metriche di valutazione per il test set e per il train set
    metrics_test=compute_metrics(test_y, pred_y_test, cm_test)
    metrics_train=compute_metrics(train_y, pred_y_train, cm_train)

    return metrics_test, metrics_train, kvalue


# questa funzione crea un plot di precision al variare di k
# in questo modo siamo in grado di visualizzare la varialià della precision
def createPlot_kNN(metrics_train, metrics_test, k_values=range(1, 21), titolo=None, loc='Precision'):
    # trasformo la colonna loc in un numpy array, di default Precision, sia per le metriche di training che di test
    m_test = metrics_test.loc[loc].to_numpy()
    m_train = metrics_train.loc[loc].to_numpy()

    # inziializzo liste precision training set, precision test set
    train = []
    test = []

    # creo un plot dove rapporto k e accuracy
    plt.figure(figsize=(9, 9))

    # imaggazzino all'interno delle liste i valori di precision per il training set e per il test set
    for k in k_values:
        score_train = m_train[k-1]
        score_test = m_test[k-1]

        train = train + [score_train]
        test = test + [score_test]

    # solite impostazioni per il plot
    plt.plot(k_values, train, lw=2, color='r') # plotto la precision per il training set
    plt.plot(k_values, test, lw=2, color='g') # plotto la precision per il test set
    plt.xlim([1, max(k_values)]) # imposto i limiti degli assi
    plt.grid(True, axis='both', zorder=0, linestyle=':', color='k') # imposto la griglia
    plt.xlabel('k value', fontsize=24) # imposto l'etichetta dell'asse x
    plt.ylabel(loc, fontsize=24) # imposto l'etichetta dell'asse y
    plt.title(titolo, fontsize=24) # imposto il titolo del plot
    plt.legend(['Train', 'Test']) # imposto la legenda
    plt.show()


# questa funzione crea un subplot di ROC curve per k = 1, 5, 10, 15, 20
def createROC_kNN(train_x, test_x, train_y, test_y, titolo=None):
    # lista di k = 1, 5, 10, 15, 20
    k_values = [1, 5, 10, 15, 20]
    # creo un plot con 5 subplot
    fig, axes = plt.subplots(1, 5, figsize=(15, 5))

    # for loop per provare diversi valori di k
    for i, k in enumerate(k_values):
        kNN_clf = KNeighborsClassifier(n_neighbors=k) # creo il modello kNN con iperparametro k={1, 5, 10, 15, 20}

        kNN_clf.fit(train_x, train_y) # addesatro il modello kNN
        pred_proba_y = kNN_clf.predict_proba(test_x) # predico le probabilità delle classi del test set

        fpr, tpr, thresholds = roc_curve(test_y, pred_proba_y[:, 1], pos_label=1) # calcolo i valori di fpr e tpr per la ROC curve
        roc_auc = auc(fpr, tpr) # calcolo l'area sotto la curva ROC
        # stampo la linea per la ROC curve, in questo caso la label sarà l'area sotto la curva ROC
        axes[i].plot(fpr, tpr, color='darkorange', label="ROC curve (area = %0.2f)" % roc_auc)
        # stampo la linea per a predizione casuale
        axes[i].plot([0, 1], [0, 1], color="navy", linestyle="--")
        # imposto i limiti degli assi
        axes[i].set_xlim([-0.005, 1.005])
        axes[i].set_ylim([-0.005, 1.005])
        # imposto le etichette degli assi
        axes[i].set_xlabel("False Positive Rate")
        axes[i].set_ylabel("True Positive Rate")
        # imposto la legenda
        axes[i].legend(loc="lower right")
        # imposto il titolo del subplot
        axes[i].set_title("k = %d" % k)

    plt.suptitle(titolo, fontsize=24) # imposto il titolo del plot
    plt.show()


def kNN(X, y, titolo=None, stratify=None):
    # suddivido il dataset in train e test set, con test_size=0.25, quindi il test set sarà composto dal 25% del dataset
    train_x, test_x, train_y, test_y = train_test_split(X, y, test_size=0.25, random_state=0, stratify=stratify)
    '''metrics_test, metrics_train, k_values = kNN_classifier(train_x, test_x, train_y, test_y)

    # trasformo le liste in dataframe
    df_metrics_test = metrics_df(k_values, metrics_test)
    df_metrics_train = metrics_df(k_values, metrics_train)

    # stampo le metriche di valutazione per il test set
    print('Metriche di valutazione, test set:\n', df_metrics_test)
    # variabile precisione
    prec = df_metrics_test.loc['Precision'].values
    # variabile di TP
    TP = df_metrics_test.loc['TP'].values
    # estraggo l'argomento del massimo dalla lista di precision
    # visto che il parametro k inizia da 1, aggiungo 1 all'argomento
    i = np.argmax(prec)
    best_k = i + 1
    print("il valore di k che porta precisione migliore è",best_k,
          "che classifica",TP[i],"TP con precisione",prec[i],
          "senza cambiare alcun iperparametro eccetto k")

    # prova i differenti valori di k, in questo caso da 1 a 20, e crea un plot dei risultati di precision
    createPlot_kNN(df_metrics_train, df_metrics_test, k_values, titolo) # Togliere il commento a questa riga per vedere il plot
    # in questo modo siamo in grado di capire come varia la precision al variare di k
    # subplot di ROC curve; k = 1, 5, 10, 15, 20
    createROC_kNN(train_x, test_x, train_y, test_y, titolo)  # Togliere il commento a questa riga per vedere il plot
    # in questo modo siamo in grado di capire come varia la ROC curve al variare di k

    # eseguiamo il tuning del parametro k pesando le distanze
    # il procedimento è molto simile a quello appena effettuato
    metrics_test, metrics_train, k_values = kNN_weights(train_x, test_x, train_y, test_y)
    df_metrics_test = metrics_df(k_values, metrics_test)
    df_metrics_train = metrics_df(k_values, metrics_train)
    print('Metriche di valutazione, test set:\n', df_metrics_test)
    prec = df_metrics_test.loc['Precision'].values
    TP = df_metrics_test.loc['TP'].values
    i = np.argmax(prec)
    best_k_weight = i + 1
    print("il valore di k che porta precisione migliore è",best_k_weight,
          "che classifica",TP[i],"TP con precisione",prec[i],"pesando le distanze")
    createPlot_kNN(df_metrics_train, df_metrics_test, k_values, titolo)
    createROC_kNN(train_x, test_x, train_y, test_y, titolo)

    # eseguiamo il tuning del parametro k utilizzando la distanza Manhattan invece di quella euclidea
    # il procedimento è molto simile a quello appena effettuato
    metrics_test, metrics_train, k_values = kNN_manhattan(train_x, test_x, train_y, test_y)
    df_metrics_test = metrics_df(k_values, metrics_test)
    df_metrics_train = metrics_df(k_values, metrics_train)
    print('Metriche di valutazione, test set:\n', df_metrics_test)
    prec = df_metrics_test.loc['Precision'].values
    TP = df_metrics_test.loc['TP'].values
    i = np.argmax(prec)
    best_k_manhattan = i + 1
    print("il valore di k che porta precisione migliore è",best_k_manhattan,
          "che classifica",TP[i],"TP con precisione",prec[i],"utilizzando la distanza Manhattan")
    createPlot_kNN(df_metrics_train, df_metrics_test, k_values, titolo)
    createROC_kNN(train_x, test_x, train_y, test_y, titolo)'''

    # viene passato il miglior valore di k deciso dai dati grezzi e viene scelto se pesare e che distanza
    # usare in base alle migliori prestazioni
    metrics_test, metrics_train, kvalue = kNN_tuned(train_x, test_x, train_y, test_y, 2, 'uniform', 1)
    df_metrics_test = metrics_df([kvalue], [metrics_test])
    df_metrics_train = metrics_df([kvalue], [metrics_train])
    print('Metriche di valutazione, test set:\n', df_metrics_test)
    prec = df_metrics_test.loc['Precision'].values
    TP = df_metrics_test.loc['TP'].values
    i = np.argmax(prec)
    print("il valore di k che porta precisione migliore è",kvalue,
          "che classifica",TP[i],"TP con precisione",prec[i],"con k=2, weight=uniform e p=1")

    # subplot di ROC curve; k = 1, 5, 10, 15, 20
    createROC_kNN_tuned(train_x, test_x, train_y, test_y, titolo)
    # in questo modo siamo in grado di capire come varia la ROC curve al variare di k


# crea un plot con la curva ROC del kNN con k=2, weight=distance e p=2
def createROC_kNN_tuned(train_x, test_x, train_y, test_y, titolo):
    kNN_clf = KNeighborsClassifier(n_neighbors=2, weights='distance', p=2) # creo il modello kNN con iperparametro k={1, 5, 10, 15, 20}

    kNN_clf.fit(train_x, train_y) # addestro il modello kNN
    pred_proba_y = kNN_clf.predict_proba(test_x) # predico le probabilità delle classi del test set

    fpr, tpr, thresholds = roc_curve(test_y, pred_proba_y[:, 1], pos_label=1) # calcolo i valori di fpr e tpr per la ROC curve
    roc_auc = auc(fpr, tpr) # calcolo l'area sotto la curva ROC
    # stampo la linea per la ROC curve, in questo caso la label sarà l'area sotto la curva ROC
    plt.plot(fpr, tpr, color='darkorange', label="ROC curve (area = %0.2f)" % roc_auc)
    # stampo la linea per a predizione casuale
    plt.plot([0, 1], [0, 1], color="navy", linestyle="--")
    # imposto i limiti degli assi
    plt.xlim([-0.005, 1.005])
    plt.ylim([-0.005, 1.005])
    # imposto le etichette degli assi
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    # imposto la legenda
    plt.legend(loc="lower right")
    # imposto il titolo del subplot
    plt.title("k = 2, weight=distance, p=2")

    plt.title(titolo, fontsize=24) # imposto il titolo del plot
    plt.show()