from analisi_dati import fetch_dataset
from menu import menu
import os


def main():
    # commentare il comando per vedere i warning che riproduceva.
    # erano dei warning relativi al qt.qpa.fonts e l'unico modo trovato per toglierli è questo
    os.environ['QT_LOGGING_RULES'] = 'qt.qpa.fonts=false'

    gamma_telescope = fetch_dataset() # prendo il dataset
    menu(gamma_telescope)


if __name__ == '__main__':
    main()