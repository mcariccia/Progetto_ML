from analisi_dati import analysis, extractXy
from kNN_clf import kNN
from pre_proc import pre_proc
from dTree_clf import dTree
from multiple_clf import multiple


# stampa i "crediti" del progetto
def print_credits():
    print("Questo progetto è stato sviluppato da:\nGabriele Carta\nMarco Boi\nAlice Mastio\nEmanuele Piras\nLorenzo Agostino Cadinu\n")


# stampa le opzioni disponibili
def print_options():
    print("\nIl programma è in grado di effettuare le seguenti funzioni:")
    print("1. Effettuare l'analisi del dataset")
    print("2. Effettuare la classificazione del dataset")
    print("3. Effettuare pre-processing del dataset")
    print("4. Esci dal programma")


# stampa le opzioni disponibili per la classificazione del dataset
def print_options_clf():
    print("\nIl programma è in grado di effettuare la classificazione del dataset con i seguenti classificatori:")
    print("1. kNN di scikit-learn")
    print("2. Albero decisionale di scikit-learn")
    print("3. Classificatore multiplo custom")
    print("4. Esci dal programma")


# esegue il classificatore scelto
def clf_options(X, y, stratify=None):
    print_options_clf()
    choice = choose_option(1, 4)
    execute_clf(choice, X, y, 'grezzo', stratify=stratify)


# esegue il classificatore scelto
def execute_clf(choice, X, y, tipo, stratify=None):
    match choice:
        case 1:
            print("Eseguo classificatore kNN di scikit-learn su dataset %s con stratificazione %s..." %
                  (tipo, 'attiva' if stratify is not None else 'disattivata'))
            kNN(X, y, 'Prestazioni su dataset %s' % tipo, stratify)
        case 2:
            print("Eseguo classificatore Albero decisionale di scikit-learn su dataset %s con stratificazione %s..." %
                  (tipo, 'attiva' if stratify is not None else 'disattivata'))
            dTree(X, y, tipo, stratify)
        case 3:
            print("Eseguo classificatore multiplo custom su dataset %s con strafificazione %s..." %
                  (tipo, 'attiva' if stratify is not None else 'disattivata'))
            multiple(X, y, tipo, stratify)
        case 4:
            print("\nArrivederci!")
            print_credits()
            exit()


# prende in input la scelta dell'utente e esegue i controlli necessari
def choose_option(min, max):
    test_int = True

    # prendo in input la scelta dell'utente
    while test_int:
        try:
            choice = int(input("\nInserisci la tua scelta: "))
            test_int = False
        except ValueError:
            print("Errore: inserire un numero intero!")

        if choice < min or choice > max:
            print("Errore: inserire un numero compreso tra", min, "e", max)
            test_int = True

    return choice


# prende in input il dataset e restituisce X e y in formato numpy array con le classi rimpiazzate da 0 e 1
def extractXy_replace(dataset):
    X, y = extractXy(dataset)
    y = y.replace({'g': 1, 'h': 0})
    X = X.to_numpy()
    y = y.to_numpy()

    return X, y


# stampa le opzioni disponibili per il pre-processing del dataset
def print_options_pre_proc():
    print("\nIl programma è in grado di effettuare i seguenti tipi di pre-processing:")
    print("1. Oversampling")
    print("2. Undersampling")
    print("3. Selezione attributi")
    print("4. Aggregazione attributi")
    print("5. Standardizzazione attributi")
    print("6. Stratificazione")
    print("7. Esci dal programma")


def pre_proc_options(X, y):
    print_options_pre_proc()

    choice = choose_option(1, 7)
    X_resampled, y_resampled, stratify = execute_pre_proc(choice, X, y)

    # classificatori
    print_options_clf()
    choice = choose_option(1, 4)
    execute_clf(choice, X_resampled, y_resampled, 'pre-processato', stratify=stratify)


def oversampling_options():
    print("\nIl programma è in grado di effettuare i seguenti tipi di oversampling:")
    print("1. Random oversampling")
    print("2. SMOTE")
    print("3. ADASYN")
    print("4. Esci dal programma")
    choice = choose_option(1, 4)

    return choice


def undersampling_options():
    print("\nIl programma è in grado di effettuare i seguenti tipi di undersampling:")
    print("1. Random undersampling")
    print("2. Probabilistic undersampling")
    print("3. NearMiss_v1")
    print("4. Esci dal programma")
    choice = choose_option(1, 4)

    return choice


def execute_pre_proc(choice, X, y):
    X_resampled = None
    y_resampled = None
    stratify = None

    match choice:
        case 1:
            os_choice = oversampling_options()

            if os_choice == 4:
                print("\nArrivederci!")
                print_credits()
                exit()

            print("Eseguo oversampling...")
            X_resampled, y_resampled = pre_proc(X, y, 1, tipo_bil=os_choice)
        case 2:
            us_choice = undersampling_options()

            if us_choice == 4:
                print("\nArrivederci!")
                print_credits()
                exit()

            print("Eseguo undersampling...")
            X_resampled, y_resampled = pre_proc(X, y, 2, tipo_bil=us_choice)
        case 3:
            print("Eseguo selezione attributi...")
            X_resampled, y_resampled = pre_proc(X, y, 3)
        case 4:
            n_components = input("Quanti attributi vuoi ottenere?")

            while True:
                try:
                    n_components = int(n_components)
                    if n_components < 1 or n_components > 10:
                        raise ValueError("Il numero deve essere compreso tra 1 e 10.")
                    break  # esce fuori dal ciclo while se le condizioni sono soddisfatte
                except ValueError:
                    print("Errore: inserire un numero valido compreso tra 1 e 10.")
                    n_components = input("Quanti attributi vuoi ottenere?")

            print("Eseguo aggregazione attributi con il metodo PCA (Principal Components Analysis)...")
            X_resampled, y_resampled = pre_proc(X, y, 4, n_components=n_components)
        case 5:
            # eseguo standardizzazione
            print("Eseguo standardizzazione dataset...")
            X_resampled, y_resampled = pre_proc(X, y, 5)
        case 6:
            print("La prossima funzione verrà eseguita con la stratificazione attiva")
            X_resampled, y_resampled = X, y
            stratify = y
        case 7:
            print("\nArrivederci!")
            print_credits()
            exit()

    return X_resampled, y_resampled, stratify


# esegue l'opzione scelta dall'utente
def execute_option(choice, dataset, X, y):
    match choice:
        case 1:
            print("Effettuo l'analisi del dataset...")
            analysis(dataset)
        case 2:
            clf_options(X, y, stratify=None)
        case 3:
            pre_proc_options(X, y)
        case 4:
            print("\nArrivederci!")
            print_credits()
            exit()


def menu(dataset):
    print('Benvenuto nel programma di classificazione di immagini di telescopi a raggi gamma!')
    # stampa i crediti
    print_credits()
    # stampa le opzioni disponibili
    print_options()

    # prendo in input la scelta dell'utente
    choice = choose_option(1, 4)
    X, y = extractXy_replace(dataset)
    execute_option(choice, dataset, X, y)