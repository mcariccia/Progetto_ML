import numpy as np
import pandas as pd


def compute_accuracy(pred_y, test_y):
    return (pred_y == test_y).sum() / len(pred_y)


def compute_error_rate(pred_y, test_y):
    return (pred_y != test_y).sum() / len(pred_y)


# funzione per il calcolo delle prestazioni in un problema multiclasse
def compute_performances(cm):
    # questa funzione calcola le metriche di valutazione del modello
    # accuracy, error rate, TPR, TNR, FPR, FNR, precision, recall, F1

    # definiamo un valore di eps per evitare divisione per 0
    eps = np.finfo(float).eps

    # calcolo delle prestazioni in un problema binario
    TP = cm[1, 1]
    TN = cm[0, 0]
    FP = cm[0, 1]
    FN = cm[1, 0]
    TPR = TP / (TP + FN + eps)
    TNR = TN / (TN + FP + eps)
    FPR = FP / (TN + FP + eps)
    FNR = FN / (TP + FN + eps)
    p = TP / (TP + FP + eps)
    r = TPR
    F1 = 2 * r * p / (r + p + eps)

    return TP, TPR, TNR, FPR, FNR, p, r, F1


def compute_metrics(test_y, pred_y, cm):
    # calcolo le metriche di valutazione
    TP, TPR, TNR, FPR, FNR, p, r, F1 = compute_performances(cm)

    # inserisco tutto in una lista accuracy, error rate, TPR, TNR, FPR, FNR, precision, recall, F1
    metrics = [round(compute_accuracy(test_y, pred_y), 2), round(compute_error_rate(test_y, pred_y), 2), TP,
               round(TPR, 2), round(TNR, 2), round(FPR, 2), round(FNR, 2), round(p, 2), round(r, 2), round(F1, 2)]

    # metrics = valori delle metriche di valutazione in ordine
    # ritorno la lista
    return metrics


def metrics_df(columns, metrics):
    # metriche di valutazione
    rows = ['Accuracy', 'Error rate', 'TP', 'TPR', 'TNR', 'FPR', 'FNR', 'Precision', 'Recall', 'F1']

    # posiziona le metriche di valutazione in una tabella, e la stampa
    df = pd.DataFrame(metrics, index=columns, columns=rows).transpose() # ho dovuto usare transpose() per avere le metriche in colonna e non in riga

    return df

