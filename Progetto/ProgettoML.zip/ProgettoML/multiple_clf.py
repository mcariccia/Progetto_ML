from sklearn.model_selection import train_test_split, StratifiedShuffleSplit
from sklearn.tree import DecisionTreeClassifier
from statistics import mode
from sklearn.metrics import confusion_matrix
from metrics import compute_metrics, metrics_df


# creazione del modello di classificazione multiplo
class Multiple_clf:

    # inizializzazione dei classificatori
    # il primo classificatore ha iperparametri max_depth=12, max_leaf_nodes=16
    # il secondo classificatore ha iperparametri min_impurity_decrease=0.005
    # il terzo classificatore ha iperparametri min_impurity_decrease=0.05
    def __init__(self):
        self.classifiers = [DecisionTreeClassifier(max_depth=12, max_leaf_nodes=16, random_state=0),
                            DecisionTreeClassifier(min_impurity_decrease=0.005, random_state=0),
                            DecisionTreeClassifier(min_impurity_decrease=0.05, random_state=0)]

    # funzione per il fit dei classificatori
    def fit(self, X, y):
        # fit dei classificatori
        for clf in self.classifiers:
            clf.fit(X, y)

    # funzione per la predizione dei classificatori
    def single_predict(self, X):
        # predizione dei classificatori
        pred_y_list = []

        # predizione dei classificatori
        for clf in self.classifiers:
            # predizione del classificatore
            pred_y = clf.predict(X)
            # aggiunta della predizione alla lista
            pred_y_list.append(pred_y)

        return pred_y_list


    # funzione per il voto a maggioranza
    def hard_voting(self, pred_y_list):
        # voto a maggioranza
        l_final = [mode([list[i] for list in pred_y_list]) for i in range(len(pred_y_list[0]))]
        return l_final


def multiple_clf_custom(X, y, stratify=None):
    # divide il dataset in training e test set, con un test_size del 0.25
    train_x, test_x, train_y, test_y = train_test_split(X, y, test_size=0.25, random_state=0, stratify=stratify)

    metrics_test = []

    # creo il classificatore multiplo
    multiple_clf = Multiple_clf()

    # fit dei classificatori
    multiple_clf.fit(train_x, train_y)
    # predizione dei classificatori
    pred_y = multiple_clf.single_predict(test_x)

    # voto a maggioranza
    pred_y_final = multiple_clf.hard_voting(pred_y)

    # calcolo la matrice di confusione, e calcolo le metriche di valutazione sulle predizioni del primo classificatore
    cm_test = confusion_matrix(test_y, pred_y[0], labels=[0, 1])
    metrics_test.append(compute_metrics(test_y, pred_y[0], cm_test))


    # calcolo la matrice di confusione, e calcolo le metriche di valutazione sulle predizioni del secondo classificatore
    cm_test = confusion_matrix(test_y, pred_y[1], labels=[0, 1])
    metrics_test.append(compute_metrics(test_y, pred_y[1], cm_test))

    # calcolo la matrice di confusione, e calcolo le metriche di valutazione sulle predizioni del terzo classificatore
    cm_test = confusion_matrix(test_y, pred_y[2], labels=[0, 1])
    metrics_test.append(compute_metrics(test_y, pred_y[2], cm_test))

    # calcolo la matrice di confusione, e calcolo le metriche di valutazione sulle predizioni finali
    cm_test = confusion_matrix(test_y, pred_y_final, labels=[0, 1])
    metrics_test.append(compute_metrics(test_y, pred_y_final, cm_test))

    return metrics_test


def multiple(X, y, tipo, stratify=None):
    metrics_test = multiple_clf_custom(X, y, stratify)

    columns = ["Clf_1", "Clf_2", "Clf_3", "Clf_final"]

    # trasformo le liste in dataframe
    df_metrics_test = metrics_df(columns, metrics_test)

    # stampo le metriche di valutazione per il test set
    print('Metriche di valutazione, test set, su dataset %s:\n' % tipo, df_metrics_test)