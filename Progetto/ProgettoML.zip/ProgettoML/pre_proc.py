import matplotlib.pyplot as plt
from collections import Counter
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
from sklearn.model_selection import train_test_split
from imblearn.under_sampling import RandomUnderSampler, InstanceHardnessThreshold, NearMiss
from imblearn.over_sampling import RandomOverSampler, SMOTE, ADASYN
from sklearn.decomposition import PCA


# questa funzione prende in input X e y e restituisce il dataset pre-processato
# argomento tipo: 1 = oversampling, 2 = undersampling, 3 = selezione attributi, 4 = aggregazione attributi
def pre_proc(X, y, tipo, tipo_bil=None, n_components=3):
    X_resampled = None
    y_resampled = None

    match tipo:
        case 1:
            # eseguo oversampling
            X_resampled, y_resampled = bilanciamento(X, y, 1, tipo_bil)
        case 2:
            # eseguo undersampling
            X_resampled, y_resampled = bilanciamento(X, y, 2, tipo_bil)
        case 3:
            # eseguo selezione attributi
            # la selezione degli attributi è stata fatta manualmente, eliminando gli attributi con meno valori unici
            # e quindi dSize, fConc e fConc1
            # è possibile ottenere il grafico con i valori unici degli attributi attraverso la funzione di analisi del dataset
            X = pd.DataFrame(X, columns=['fLength', 'fWidth', 'fSize', 'fConc', 'fConc1', 'fAsym', 'fM3Long', 'fM3Trans', 'fAlpha', 'fDist'])
            X.drop(['fSize', 'fConc', 'fConc1'], axis=1, inplace=True)
            X_resampled = X.to_numpy()
            y_resampled = y
        case 4:
            # eseguo aggregazione attributi
            pca = PCA(n_components=n_components)
            X_resampled = pca.fit_transform(X, y)
            y_resampled = y
        case 5:
            # eseguo standardizzazione dataset
            scaler = MinMaxScaler()
            scaler.fit(X) # addestro l'algoritmo sui dait da scalare

            # scalo i dati del dataframe per ottenere valori compresi tra 0 e 1
            X_resampled = scaler.transform(X)
            y_resampled = y
        case _:
            print('Tipo di pre-processing non valido, provare a selezionare uno dei seguenti: 1, 2, 3, 4')

    return X_resampled, y_resampled


# questa funzione bilancia il dataset
# tipo = 1 per oversampling, tipo = 2 per undersampling
# tipo_bil oversampling = 1 per random, tipo_bil = 2 per smote, tipo_bil = 3 per adasyn
# tipo_bil undersampling = 1 per random, tipo_bil = 2 per prob, tipo_bil = 3 per nmv1
def bilanciamento(X, y, tipo, tipo_bil):
    # stampo il numero di istanze per classe e uno scatter plot del dataset originale
    print('Dataset originale, pre bilanciamento: %s' % sorted(Counter(y).items()))
    scatter_plot(X, y, 'Dataset originale, pre bilanciamento') # scatter plot del dataset originale

    # suddivido il dataset in training set e test set, con test_size=0.25, quindi il test set sarà composto dal 25%
    # del dataset
    train_x, test_x, train_y, test_y = train_test_split(X, y, test_size=0.25, random_state=0)

    # stampo il numero di istanze per classe del training set e uno scatter plot del training set
    print('Training set, pre bilanciamento: %s' % sorted(Counter(train_y).items()))
    scatter_plot(train_x, train_y, 'Training set, pre bilanciamento') # scatter plot del training set
    # stampare un plot del test set non è necessario perché non andremo a bilanciarlo bilanciare il training set ha
    # senso perché vogliamo che il modello abbia abbastanza istanze per imparare a classificare bene bilanciare il
    # test set invece non è necessario, anzi avere un test set sbilanciato potrebbe tornare utile proprio per capire
    # quanto il modello è in grado di classificare bene anche istanze di classe minoritaria

    # bilanciamento del training set
    # possiamo procedere con undersampling o oversampling, in questo caso useremo i seguenti
    # - undersampling
    # - oversampling

    # inizializzo
    X_resampled = None
    y_resampled = None

    if tipo == 1:
        # tipi di oversampling, la funzione ritorna X_resampled e y_resampled, che sono il training set bilanciato
        match tipo_bil:
            case 1:
                X_resampled, y_resampled = oversampling(train_x, train_y, tipo='random',
                                                        titolo='Training set dopo il random oversampling')
            case 2:
                X_resampled, y_resampled = oversampling(train_x, train_y, tipo='smote',
                                                        titolo='Training set dopo il SMOTE oversampling')
            case 3:
                X_resampled, y_resampled = oversampling(train_x, train_y, tipo='adasyn',
                                                        titolo='Training set dopo il ADASYN oversampling')
    elif tipo == 2:
        # tipi di undersampling, la funzione ritorna X_resampled e y_resampled, che sono il training set bilanciato
        match tipo_bil:
            case 1:
                X_resampled, y_resampled = undersampling(train_x, train_y, tipo='random',
                              titolo='Training set dopo il random undersampling')
            case 2:
                X_resampled, y_resampled = undersampling(train_x, train_y, tipo='prob',
                              titolo='Training set dopo il probabilistico undersampling')
            case 3:
                X_resampled, y_resampled = undersampling(train_x, train_y, tipo='nmv1',
                                                 titolo='Training set dopo il NearMiss_v1 undersampling')
    else:
        print('Tipo di bilanciamento non valido, provare a selezionare uno dei seguenti: under, over')

    return X_resampled, y_resampled


# questa funzione crea uno scatter plot del dataset originale
# riusciamo a capire nuovamente la distribuzione dei dati
def scatter_plot(X, y, titolo=None):
    plt.figure(num=0, dpi=96, figsize=(4, 4))
    plt.scatter(X[y == 0, 0], X[y == 0, 1], color='orange', marker='s', label='Class h', s=12, alpha=0.5) # plotto le istanze di classe h con alpha=0.3 per renderle più chiare
    plt.scatter(X[y == 1, 0], X[y == 1, 1], color='purple', marker='o', label='Class g', s=12, alpha=0.5) # plotto le istanze di classe g
    plt.title(titolo)
    plt.legend() # per mostrare la legenda
    plt.show() # per mostrare il plot


# questa funzione bilancia il dataset sfruttando il metodo di undersampling
# il metodo di undersampling in questo caso è suddiviso in 3 tipi:
# - random
# - probabilistico
# - NearMiss_v1
def undersampling(X, y, tipo='random', titolo=None):
    if tipo == 'random':  # esegue undersampling di tipo random
        rus = RandomUnderSampler(random_state=0)  # creo un oggetto RandomUnderSampler
        X_resampled, y_resampled = rus.fit_resample(X, y)  # applico il metodo fit_resample per bilanciare il dataset
        print('Training set dopo il random undersampling %s:' % sorted(Counter(y_resampled).items()))
        scatter_plot(X_resampled, y_resampled, titolo)  # crea plot del dataset bilanciato

        return X_resampled, y_resampled
    elif tipo == 'prob':  # esegue undersampling di tipo probabilistico
        iht = InstanceHardnessThreshold(random_state=0)  # creo un oggetto InstanceHardnessThreshold
        X_resampled, y_resampled = iht.fit_resample(X, y)  # applico il metodo fit_resample per bilanciare il dataset
        print('Training set dopo il probabilistico undersampling %s' % sorted(Counter(y_resampled).items()))
        scatter_plot(X_resampled, y_resampled, titolo)  # crea plot del dataset bilanciato

        return X_resampled, y_resampled
    elif tipo == 'nmv1':  # esegue undersampling di tipo NearMiss_v1
        nm = NearMiss(version=1)  # creo un oggetto NearMiss
        X_resampled, y_resampled = nm.fit_resample(X, y)  # applico il metodo fit_resample per bilanciare il dataset
        print('Training set dopo il NearMiss_v1 undersampling %s' % sorted(Counter(y_resampled).items()))
        scatter_plot(X_resampled, y_resampled, titolo)  # crea plot del dataset bilanciato

        return X_resampled, y_resampled
    else:
        print('Tipo di undersampling non valido, provare a selezionare uno dei seguenti: random, prob, nmv1')


# questa funzione bilancia il dataset sfruttando il metodo di oversampling
# il metodo di undersampling in questo caso è suddiviso in 3 tipi:
# - random
# - SMOTE
# - ADASYN
def oversampling(X, y, tipo='random', titolo=None):
    X_resampled = None
    y_resampled = None

    if tipo == 'random':  # esegue oversampling di tipo random
        ros = RandomOverSampler(random_state=42)  # creo un oggetto RandomOverSampler
        X_resampled, y_resampled = ros.fit_resample(X, y)  # applico il metodo fit_resample per bilanciare il dataset
        print('Training set dopo random oversampling %s' % sorted(Counter(y_resampled).items()))
        scatter_plot(X_resampled, y_resampled, titolo)  # crea plot del dataset bilanciato
    elif tipo == 'smote':  # esegue oversampling di tipo SMOTE
        sm = SMOTE(random_state=42)  # creo un oggetto SMOTE
        X_resampled, y_resampled = sm.fit_resample(X, y)  # applico il metodo fit_resample per bilanciare il dataset
        print('Training set dopo SMOTE oversampling %s' % sorted(Counter(y_resampled).items()))
        scatter_plot(X_resampled, y_resampled, titolo)  # crea plot del dataset bilanciato
    elif tipo == 'adasyn':  # esegue oversampling di tipo ADASYN
        ada = ADASYN(random_state=42)  # creo un oggetto ADASYN
        X_resampled, y_resampled = ada.fit_resample(X, y)  # applico il metodo fit_resample per bilanciare il dataset
        print('Training set dopo ADASYN oversampling %s' % sorted(Counter(y_resampled).items()))
        scatter_plot(X_resampled, y_resampled, titolo)  # crea plot del dataset bilanciato
    else:
        print('Tipo di oversampling non valido, provare a selezionare uno dei seguenti: random, smote, adasyn')

    return X_resampled, y_resampled
